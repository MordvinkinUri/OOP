﻿
using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("1 - Двумерный массив");
        Console.WriteLine("2 - Рваный массив");
        Console.WriteLine("3 - Работа со строкой");

        int n;
        Console.Write("Выберите задание: ");

        if (!int.TryParse(Console.ReadLine(), out n))
        {
            Console.WriteLine("Ошибка ввода");
            return;
        }

        if (n == 1)
        {
            Console.Write("Количество строк: ");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Количество столбцов: ");
            int b = Convert.ToInt32(Console.ReadLine());

            int[,] mas = new int[a, b];

            for (int i = 0; i < a; i++)
            {
                for (int j = 0; j < b; j++)
                {
                    Console.Write("Введите число: ");
                    mas[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.Write("Сколько строк добавить: ");
            int k = Convert.ToInt32(Console.ReadLine());

            int[,] mas2 = new int[a + k, b];

            for (int i = 0; i < a; i++)
            {
                for (int j = 0; j < b; j++)
                {
                    mas2[i + k, j] = mas[i, j];
                }
            }

            Console.WriteLine("Новый массив:");

            for (int i = 0; i < a + k; i++)
            {
                for (int j = 0; j < b; j++)
                {
                    Console.Write(mas2[i, j] + " ");
                }

                Console.WriteLine();
            }
        }
        else if (n == 2)
        {
            Console.Write("Количество строк: ");
            int a = Convert.ToInt32(Console.ReadLine());

            int[][] mas = new int[a][];

            for (int i = 0; i < a; i++)
            {
                Console.Write("Количество элементов в строке: ");
                int b = Convert.ToInt32(Console.ReadLine());

                mas[i] = new int[b];

                for (int j = 0; j < b; j++)
                {
                    Console.Write("Введите число: ");
                    mas[i][j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.Write("Номер строки для удаления: ");
            int k = Convert.ToInt32(Console.ReadLine());

            if (k < 1 || k > a)
            {
                Console.WriteLine("Такой строки нет");
                return;
            }

            Console.WriteLine("Результат:");

            for (int i = 0; i < a; i++)
            {
                if (i != k - 1)
                {
                    for (int j = 0; j < mas[i].Length; j++)
                    {
                        Console.Write(mas[i][j] + " ");
                    }

                    Console.WriteLine();
                }
            }
        }
        else if (n == 3)
        {
            Console.Write("Введите предложение: ");
            string s = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(s))
            {
                Console.WriteLine("Строка пустая");
                return;
            }

            string[] words = s.Split(' ');

            for (int i = 0; i < words.Length; i++)
            {
                string word = words[i];
                string cleanWord = word.Trim(
                    '.', ',', '!', '?', ':', ';');

                if (cleanWord.Length == i + 1)
                {
                    char[] chars = word.ToCharArray();
                    Array.Reverse(chars);
                    words[i] = new string(chars);
                }
            }

            Console.WriteLine(string.Join(" ", words));
        }
    }
}
