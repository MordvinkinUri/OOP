﻿using System;

interface IInit
{
    void Init();
    void RandomInit();
}

class Production : IInit, IComparable, ICloneable
{
    public string Name { get; set; }
    public int Workers { get; set; }

    public Production()
    {
        Name = "Без названия";
        Workers = 0;
    }

    public Production(string name, int workers)
    {
        Name = name;
        Workers = workers;
    }

    public Production(Production p)
    {
        Name = p.Name;
        Workers = p.Workers;
    }

    public virtual void Show()
    {
        Console.WriteLine("Производство: " + Name + ", работников: " + Workers);
    }

    public void Init()
    {
        Console.Write("Название: ");
        Name = Console.ReadLine();

        Console.Write("Количество работников: ");
        Workers = int.Parse(Console.ReadLine());
    }

    public void RandomInit()
    {
        Random r = new Random();
        Name = "Объект" + r.Next(1, 100);
        Workers = r.Next(10, 500);
    }

    public int CompareTo(object obj)
    {
        Production p = (Production)obj;
        return Workers.CompareTo(p.Workers);
    }

    public virtual object Clone()
    {
        return new Production(this);
    }

    public override bool Equals(object obj)
    {
        if (obj == null || !(obj is Production))
            return false;

        Production p = (Production)obj;
        return Name == p.Name && Workers == p.Workers;
    }
}

class Shop : Production
{
    public int Machines { get; set; }

    public Shop(string name, int workers, int machines)
        : base(name, workers)
    {
        Machines = machines;
    }

    public override void Show()
    {
        Console.WriteLine("Цех: " + Name + ", работников: " + Workers +
                          ", станков: " + Machines);
    }
}

class Workshop : Production
{
    public string Specialization { get; set; }

    public Workshop(string name, int workers, string specialization)
        : base(name, workers)
    {
        Specialization = specialization;
    }

    public override void Show()
    {
        Console.WriteLine("Мастерская: " + Name + ", работников: " + Workers +
                          ", специализация: " + Specialization);
    }
}

class Factory : Production
{
    public int ShopsCount { get; set; }

    public Factory(string name, int workers, int shopsCount)
        : base(name, workers)
    {
        ShopsCount = shopsCount;
    }

    public override void Show()
    {
        Console.WriteLine("Фабрика: " + Name + ", работников: " + Workers +
                          ", цехов: " + ShopsCount);
    }
}

class Machine : IInit
{
    public void Init()
    {
        Console.WriteLine("Ручная инициализация станка");
    }

    public void RandomInit()
    {
        Console.WriteLine("Случайная инициализация станка");
    }
}

class SortByName : System.Collections.IComparer
{
    public int Compare(object a, object b)
    {
        Production p1 = (Production)a;
        Production p2 = (Production)b;
        return string.Compare(p1.Name, p2.Name);
    }
}

class Program
{
    static void Main()
    {
        Production[] items =
        {
            new Shop("Цех А", 50, 12),
            new Workshop("Мастерская Б", 20, "Ремонт"),
            new Factory("Фабрика В", 200, 5),
            new Production("Производство Г", 100)
        };

        Console.WriteLine("Исходный массив:");
        foreach (Production p in items)
            p.Show();

        Array.Sort(items);
        Console.WriteLine("\nСортировка по количеству работников:");
        foreach (Production p in items)
            p.Show();

        Array.Sort(items, new SortByName());
        Console.WriteLine("\nСортировка по названию:");
        foreach (Production p in items)
            p.Show();

        Console.WriteLine("\nПроверка типов:");
        foreach (Production p in items)
        {
            if (p is Shop)
                Console.WriteLine(p.Name + " - это цех");

            Shop s = p as Shop;
            if (s != null)
                Console.WriteLine("Количество станков: " + s.Machines);

            Console.WriteLine(p.GetType());
        }

        IInit[] objects = { new Production(), new Machine() };
        foreach (IInit obj in objects)
            obj.RandomInit();

        Production copy = (Production)items[0].Clone();
        Console.WriteLine("\nКлон объекта:");
        copy.Show();

        Console.ReadKey();
    }
}
